<?php

include('connect.php');

session_start();

//Fetch data from Payment Page
if(isset($_POST['pay'])){
    $card_num = $_POST['cardnum'];
    $month = $_POST['month'];
    $year = $_POST['year'];
    $cvv = $_POST['cvv'];


   //Fetch Session data for Booking
   if(isset($_SESSION['origin'])){
    $origin = $_SESSION['origin'];
    $destination = $_SESSION['destination'];
    $seatno = $_SESSION['seatno'];
    $date = $_SESSION['date'];
    $ac = $_SESSION['ac'];

  
    }

    //User

    $usr = $_SESSION['username'];


    $current_usr_id = "SELECT * FROM user WHERE username='$usr'";


    $res_usr_id = mysqli_query($conn,$current_usr_id);





    if($res_usr_id){
        $row_user = mysqli_fetch_array($res_usr_id);

        


        $new_seats = $_SESSION['new_seats'];
        $id = $_SESSION['id'];

        $cost = $row['rate'];

        $tot = $_SESSION['tot'];

        //Save credit card information

        $ccard = "INSERT INTO credit_card(user_id,card_num,month,year,cvv) VALUES('$row_user[id]','$card_num','$month','$year','$cvv')";

        $sql_cc = mysqli_query($conn,$ccard);

       


        $update_sql = "UPDATE routes SET seats='$new_seats' WHERE id='$id'";

        $save_book = "INSERT INTO booking(user_id,origin,destination,seats,date,type,total_cost) VALUES('$row_user[id]','$origin','$destination','$seatno','$date','$ac','$tot')";

        $res = mysqli_query($conn,$update_sql);

        $res2 = mysqli_query($conn,$save_book);


        


        if($res2){
            $last_id = $conn->insert_id;
            
            $_SESSION['last_id'] = $last_id;
            header('Location:thanks.php');
        }
        
    }
    }


    //Delete Session Vars after save to DB
    unset($_SESSION['origin']);
    unset($_SESSION['destination']);
    unset($_SESSION['seatno']);
    unset($_SESSION['tot']);
    unset($_SESSION['date']);
    unset($_SESSION['ac']);
    unset($_SESSION['new_seats']);
    unset($_SESSION['id']);
    unset($_SESSION['last_id']);

?>