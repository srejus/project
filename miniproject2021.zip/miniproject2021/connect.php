<?php

//Credentials

$server = "localhost";
$username = "root";
$password = "";
$db = "miniproject2021";

//Database Connection

$conn = mysqli_connect("$server","$username","$password");
if($conn){
    echo "<script>console.log('Connected!');</script>";
}
else{
    die("Could not connected!");
}

$select = mysqli_select_db($conn,$db);

if($select){
    echo "<script>console.log('Selected!');</script>";
}
else{
    die("<br>Error in Connecting");
}
?>