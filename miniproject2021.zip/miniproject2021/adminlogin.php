<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

	<title>Login</title>

	<!-- Google font -->
	<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet">

	<!-- Bootstrap -->
	<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css" />

	<!-- Custom stlylesheet -->
	<link type="text/css" rel="stylesheet" href="css/style.css" />


</head>

<body>
	<div id="booking-1" class="section">
		<?php
			include('nav.html');
		?>
		<div class="section-center">
			<div class="container">
				<div class="row">
					<div class="col-md-7 col-md-push-5">
						<div class="booking-cta">
							<h1>Make your reservation</h1>
							<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Animi facere, soluta magnam consectetur molestias itaque
								ad sint fugit architecto incidunt iste culpa perspiciatis possimus voluptates aliquid consequuntur cumque quasi.
								Perspiciatis.
							</p>
						</div>
					</div>
					<div class="col-md-4 col-md-pull-7">
						<div class="booking-form">
							<form action="adminlogin.php" method="POST">
                                <h1>Admin Login</h1><br>
								<div class="form-group">
									<span class="form-label">Username</span>
									<input name="username" class="form-control" type="text" placeholder="Enter your Username">
								</div>

								<div class="form-group">
									<span class="form-label">Password</span>
									<input name="password" class="form-control" type="password" placeholder="Enter your Password">
								</div>

								
								<div class="form-btn">
									<button type="submit" name="login" class="submit-btn">Login</button>
								</div><br>
							
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</body>

</html>

<?php 
include('connect.php');

//Fetch data from HTML Form

if(isset($_POST['login'])){
	$username = $_POST['username'];
	$password = $_POST['password'];

	$sql = "SELECT * FROM user WHERE username='$username' AND password='$password'";
	
	$res = mysqli_query($conn,$sql);
	if($res){
		//try to get data fromDB
		$row_num = mysqli_num_rows($res);
		if($row_num > 0){
			session_start();
			$_SESSION['username'] = $username;
			header('Location:index.php');
		}
		else{
			echo "<script>alert('Username or Password not matching!');</script>";
		}
	}
	else{
		echo "Error";
	}
	
}
?>