<?php
session_start();

if(!isset($_SESSION['admin'])){
	header('Location:adminlogin.php');
}

?>


<?php
include('connect.php');

 $del_id = $_GET['id'];

 $sql_del = "DELETE FROM routes WHERE id=$del_id";



    
$res_del = mysqli_query($conn,$sql_del);


if($res_del){
    echo "<script>alert('Route deleted!');</script>";
    header('Location:routes.php');
}


?>