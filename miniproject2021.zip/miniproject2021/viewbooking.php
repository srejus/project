<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

	<title>Admin | Booking</title>

	<!-- Google font -->
	<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet">

	<!-- Bootstrap -->
	<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css" />

	<!-- Custom stlylesheet -->
	<link type="text/css" rel="stylesheet" href="css/style.css" />


</head>

<?php

include('connect.php');
//Fetch Booking data from the server

$id = $_GET['id'];


$sql = "SELECT * FROM booking WHERE id='$id'";
$res = mysqli_query($conn,$sql);
$row = mysqli_fetch_array($res);



?>

<body>
	<div id="booking-1" class="section"><br><br>
		<a class="a" style="margin-left:50px;" href="logout.php">Logout</a>
		<div class="section-center">
			<div class="container">
				<div class="row">
					<h1 style="color:white;">Admin Panel | Booking</h1>
						<div class="booking-form" style="width:950px;">
							<div class="row">
                                <h5 style='font-size:20px;margin:10px;'>Booking Id:<?php echo "$row[id]"; ?></h5>
                                <h5 style='font-size:20px;margin:10px;'>From: <?php echo "$row[origin]"; ?></h5>
                                <h5 style='font-size:20px;margin:10px;'>To: <?php echo "$row[destination]"; ?></h5>
                                <h5 style='font-size:20px;margin:10px;'>Time: <?php echo "$row[date]"; ?></h5>
                                <h5 style='font-size:20px;margin:10px;'>No of Seats: <?php echo "$row[seats]"; ?></h5>
                                <h5 style='font-size:20px;margin:10px;'>Type of Bus: <?php echo "$row[type]"; ?></h5>
                            </div>
						</div>
					</div>
				</div>
			</div>
		</div>
	
</body>

</html>

