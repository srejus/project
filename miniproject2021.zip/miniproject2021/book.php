<?php

session_start();

if(!isset($_SESSION['username'])){
	header('Location:login.php');
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

	<title>Booking Form HTML Template</title>

	<!-- <script src="index.js"></script> -->
	

	<!-- Google font -->
	<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet">

	<!-- Bootstrap -->
	<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css" />

	<!-- Custom stlylesheet -->
	<link type="text/css" rel="stylesheet" href="css/style.css" />

	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
		  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
		  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
		<![endif]-->

</head>

<body>
	<div id="booking-1" class="section">
		<?php
			include('nav.html');
		?>
		<div class="section-center">
			<div class="container">
				<div class="row">
					<div class="col-md-7 col-md-push-5">
						<div class="booking-cta">
							<h1>Make your reservation</h1>
							<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Animi facere, soluta magnam consectetur molestias itaque
								ad sint fugit architecto incidunt iste culpa perspiciatis possimus voluptates aliquid consequuntur cumque quasi.
								Perspiciatis.
							</p>
						</div>
					</div>
					<div class="col-md-4 col-md-pull-7">
						<div class="booking-form">
							<form action="confirm.php" method="POST">
								<div class="form-group">
									<span class="form-label">Origin</span>
									
									<select id="origin" class="form-control" name="origin">
										<option value="">Select your Origin</option>
										<option value="Kochi">Kochi</option>
										<option value="Kozhikode">Kozhikode</option>
										<option value="Kollam">Kollam</option>
										<option value="Alappuzha">Alappuzha</option>
										<option value="Trivandrum">Trivandrum</option>
									</select>
								</div>

								<div class="form-group">
									<span class="form-label">Destination</span>
									<select id="destination" class="form-control" name="destination">
										<option value="">Select your Destination</option>
										<option value="Kochi">Kochi</option>
										<option value="Kozhikode">Kozhikode</option>
										<option value="Kollam">Kollam</option>
										<option value="Alappuzha">Alappuzha</option>
										<option value="Trivandrum">Trivandrum</option>
									</select>
									
								</div>

								<div class="form-group">
									<span class="form-label">No of Seats</span>
									<input id="seats" class="form-control" type="number" name="seatno" placeholder="Enter Seats needed">
								</div>

								<div class="form-group">
									<span class="form-label">Date</span>
									<input id="date" class="form-control" type="text" name="date" placeholder="Eg:12-10-2021">
								</div>

								<div class="form-group">
									<span class="form-label">Type of Bus</span><br>
									<input  name="ac" type="radio" value="ac">A/c &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
									<input name="ac" type="radio" value="nonac">Non A/C
								</div>

								<div class="form-btn">
									<button name="book" type="submit" class="submit-btn">Check availability</button>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</body>

</html>



<?php

include('connect.php');

if(isset($_POST['book'])){
	$origin = $_POST['origin'];
	$destination = $_POST['destination'];
	$seatno = $_POST['seatno'];
	$date = $_POST['date'];
	$ac = $_POST['ac'];

	echo "";


	echo "<br>$origin<br>$destination<br>$seatno<br>$date<br>$ac<br>";
	//1.Check for routes
	//2.If yes check seats available
	//3.Show it on Confirm page
	//4.Save the booking
	//5.Reduce the seat number.

	$routes = "SELECT * FROM routes WHERE origin='$origin' AND destination='$destination' AND date='$date' AND type='$ac' AND seats>='$seatno'";

	$routes_query = mysqli_query($conn,$routes);

	$row = mysqli_fetch_array($routes_query);


	$x = mysqli_num_rows($routes_query);
	if($x > 0){

		$total_seats = $row['seats'];
		$new_seats = $total_seats-$seatno;

		

		$_SESSION['new_seats'] = $new_seats;

		echo "<script>saveLocal();</script>";

		
		
		//Update the Seat number

		$id=$row['id'];

		//Current User
		
		$usr = $_SESSION['username'];
		
		

		$current_usr_id = "SELECT * FROM user WHERE username='$usr'";


		$res_usr_id = mysqli_query($conn,$current_usr_id);



		if($res_usr_id){
			$row_user = mysqli_fetch_array($res_usr_id);

	
			$update_sql = "UPDATE routes SET seats='$new_seats' WHERE id='$id'";
	
			$save_book = "INSERT INTO booking(user_id,origin,destination,seats,date,type) VALUES('$row_user[id]','$origin','$destination','$seatno','$date','$ac')";
	
			$res = mysqli_query($conn,$update_sql);
	
			$res2 = mysqli_query($conn,$save_book);
		}

		
		
	}
	else{
		echo "<script>alert('Sorry no availability of Seats!');</script>";
	}
}

?>