<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

	<title>Payment</title>

	<!-- Google font -->
	<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet">

	<!-- Bootstrap -->
	<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css" />

	<!-- Custom stlylesheet -->
	<link type="text/css" rel="stylesheet" href="css/style.css" />


</head>

<body>
	<div id="booking-1" class="section">
		<?php
			include('nav.html');
		?>
		<div class="section-center">
			<div class="container">
				<div class="row">
					<div class="col-md-7 col-md-push-5">
						<div class="booking-cta">
							<h1>Make your reservation</h1>
							<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Animi facere, soluta magnam consectetur molestias itaque
								ad sint fugit architecto incidunt iste culpa perspiciatis possimus voluptates aliquid consequuntur cumque quasi.
								Perspiciatis.
							</p>
						</div>
					</div>
					<div class="col-md-4 col-md-pull-7">
						<div class="booking-form">
							<form action="save.php" method="POST">
                                <h1>Pay with your Card</h1><br>
								<div class="form-group">
									
									<input name="cardnum" class="form-control" type="text" placeholder="Enter your card number">
								</div>


                                <div class="form-group" style="display:flex;flex-direction:row; justify-content:space-between;">
                                    
                                        <select id="month" class="form-control" style="width:120px;" name="month">
                                            <option value="">Month</option>
                                            <option value="January">January</option>
                                            <option value="February">February</option>
                                            <option value="March">March</option>
                                            <option value="April">April</option>
                                            <option value="May">May</option>
                                            <option value="June">June</option>
                                            <option value="July">July</option>
                                            <option value="August">August</option>
                                            <option value="September">September</option>
                                            <option value="October">October</option>
                                            <option value="November">November</option>
                                            <option value="December">December</option>
                                        </select>

                                        
                                        <select id="year" class="form-control" style="width:120px;"  name="year">
                                            <option value="">Year</option>
                                            <option value="2022">2022</option>
                                            <option value="2023">2023</option>
                                            <option value="2024">2024</option>
                                            <option value="2025">2025</option>
                                            <option value="2026">2026</option>
											<option value="2027">2027</option>
                                        </select>
								</div>


                                <div class="form-group">
									<input type="password" class="form-control" style="width:120px;" name="cvv" placeholder="cvv">
                                </div>

								
								<div class="form-btn">
									<button type="submit" name="pay" class="submit-btn" style="width:100%;">Proceed</button>
								</div><br>
								
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</body>

</html>

<?php 
include('connect.php');

//Fetch data from HTML Form

if(isset($_POST['login'])){
	$username = $_POST['username'];
	$password = $_POST['password'];

	$sql = "SELECT * FROM user WHERE username='$username' AND password='$password'";
	
	$res = mysqli_query($conn,$sql);
	if($res){
		//try to get data fromDB
		$row_num = mysqli_num_rows($res);
		if($row_num > 0){
			session_start();
			$_SESSION['username'] = $username;
			header('Location:index.php');
		}
		else{
			echo "<script>alert('Username or Password not matching!');</script>";
		}
	}
	else{
		echo "Error";
	}
	
}
?>