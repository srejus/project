<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

	<title>Thanks</title>

	<!-- Google font -->
	<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet">

	<!-- Bootstrap -->
	<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css" />

	<!-- Custom stlylesheet -->
	<link type="text/css" rel="stylesheet" href="css/style.css" />


</head>

<?php
session_start();
$last_id = $_SESSION['last_id'];
?>



<body>
	<div id="booking-1" class="section"><br><br>
		<div class="section-center">
			<div class="container">
				<div class="row">
					
						<div class="booking-form" style="width:950px;">
							<div class="row" style="display:flex;align-items: center;flex-direction: column;">
								<img  src="img/smile.png">
                            <h1 style="text-align: center;">Thanks For choosing Us</h1>
							<h3 style="text-align: center;">Your OTP:<?php echo "$last_id";?></h3><br><br>
							<a href="index.php">Home</a>
                             
                            </div>
						</div>
					</div>
				</div>
			</div>
		</div>
	
</body>

</html>

