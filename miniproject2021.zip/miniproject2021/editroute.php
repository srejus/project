<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

	<title>Admin | Editroute</title>

	<!-- Google font -->
	<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet">

	<!-- Bootstrap -->
	<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css" />

	<!-- Custom stlylesheet -->
	<link type="text/css" rel="stylesheet" href="css/style.css" />


</head>

<?php
session_start();

if(!isset($_SESSION['admin'])){
	header('Location:adminlogin.php');
}

$id = $_GET['id'];


?>

<body>
	<div id="booking-1" class="section">
    <a class="a" style="margin-left:50px;" href="logout.php">Logout</a><a class="a" style="margin-left:50px;" href="admin.php">Admin</a>
		<div class="section-center">
			<div class="container">
				<div class="row">
					<div class="col-md-7 col-md-push-5">
						
					</div>
					<div class="col-md-4 col-md-pull-7">
						<div class="booking-form">
							<form action="editroute.php" method="POST">
                            <h3>Edit Route</h3><br>

                              

                                <div class="form-group">
									<span class="form-label">Total seats</span>
									<input name="seats" class="form-control" type="text" placeholder="Enter Seats">
								</div>

								<div class="form-group">
									<span class="form-label">Date</span>
									<input name="date" class="form-control" type="text" placeholder="Enter New Date">
								</div>

                                <div class="form-group">
									<span class="form-label">Rate per seat</span>
									<input name="rate" class="form-control" type="number" placeholder="Enter Rate Per Ticket">
								</div>

                                <input type="hidden" value="<?php echo $id ; ?>" name="id">


								
								<div class="form-btn">
									<button type="submit" name="save" class="submit-btn">Update Route</button>
								</div><br>
								
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</body>

</html>


<?php

include('connect.php');
//Fetch data from Form


if(isset($_POST['save'])){
	$seatno = $_POST['seats'];
	$rate = $_POST['rate'];
	$date = $_POST['date'];

    $id = $_POST['id'];

    if($date != ''){
        $sql = "UPDATE routes SET date='$date'  WHERE id='$id'";

        $res = mysqli_query($conn,$sql);

    }

	if($seatno != ''){
        $sql = "UPDATE routes SET seats='$seatno'  WHERE id='$id'";

        $res = mysqli_query($conn,$sql);

    }

    if($rate != ''){
        $sql1 = "UPDATE routes SET rate='$rate'  WHERE id='$id'";

        $res = mysqli_query($conn,$sql1);

        if($res){
            echo "<script>alert('Route added!');</script>";
            header('Location:routes.php');
        }
    }

    header('Location:routes.php');
  
    
}

?>