<?php

session_start();

if(!isset($_SESSION['username'])){
	header('Location:login.php');
}

?>


<?php

include('connect.php');

if(isset($_POST['book'])){
	$origin = $_POST['origin'];
	$destination = $_POST['destination'];
	$seatno = $_POST['seatno'];
	$date = $_POST['date'];
	$ac = $_POST['ac'];


	//Setting Session Vars
	
	
	$_SESSION['origin'] = $origin;
	$_SESSION['destination']= $destination;
	$_SESSION['seatno']= $seatno;
	$_SESSION['date']= $date;
	$_SESSION['ac']= $ac;


	//1.Check for routes
	//2.If yes check seats available
	//3.Show it on Confirm page
	//4.Save the booking
	//5.Reduce the seat number.

	$routes = "SELECT * FROM routes WHERE origin='$origin' AND destination='$destination' AND date='$date' AND type='$ac' AND seats>='$seatno'";

	$routes_query = mysqli_query($conn,$routes);

	$row = mysqli_fetch_array($routes_query);

	$total_seats = $row['seats'];
	$new_seats = $total_seats-$seatno;

	$id=$row['id'];

	$_SESSION['new_seats'] = $new_seats;
	$_SESSION['id'] = $id;

	$cost = $row['rate'];
	$tot = $cost*$seatno;

	$_SESSION['tot'] = $tot;


	$x = mysqli_num_rows($routes_query);
    if($x == 0){
        header('Location:noavail.php');
    }
	
  
		
	}
    if(isset($_POST['btn'])){
		header('Location:payment.php');
        
     

		
    }

	//Fetch the Ticket Rate per Seat

	$cost = $row['rate'];

	$tot = $cost*$seatno;


?>



<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

	<title>Confirm Booking</title>

	<!-- Google font -->
	<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet">

	<!-- Bootstrap -->
	<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css" />

	<!-- Custom stlylesheet -->
	<link type="text/css" rel="stylesheet" href="css/style.css" />

	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
		  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
		  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
		<![endif]-->

</head>

<body>
	<div id="booking-1" class="section">
		<?php
			include('nav.html');
		?>
		<div class="section-center">
			<div class="container">
				<div class="row">
					<div class="col-md-7 col-md-push-5">
						<div class="booking-cta">
							<h1>Make your reservation</h1>
							<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Animi facere, soluta magnam consectetur molestias itaque
								ad sint fugit architecto incidunt iste culpa perspiciatis possimus voluptates aliquid consequuntur cumque quasi.
								Perspiciatis.
							</p>
						</div>
					</div>
					<div class="col-md-4 col-md-pull-7">
						<div class="booking-form">
							<form action="confirm.php" method="POST">
                                <h4>Seats available<br>Do you want to confirm Booking?</h4>
                                <br><br>
								
                                <h5 style='font-size:20px;margin:10px;'>From: <?php echo "$origin"; ?></h5>
                                <h5 style='font-size:20px;margin:10px;'>To: <?php echo "$row[destination]"; ?></h5>
                                <h5 style='font-size:20px;margin:10px;'>Time: <?php echo "$row[date]"; ?></h5>
                                <h5 style='font-size:20px;margin:10px;'>No of Seats: <?php echo "$seatno"; ?></h5>
                                <h5 style='font-size:20px;margin:10px;'>Type of Bus: <?php echo "$row[type]"; ?></h5>
								<h5 style='font-size:20px;margin:10px;'>Total Ticket Cost: <?php echo "$tot RS"; ?></h5>
								<br><br>
							<input type="submit" class="submit-btn" value="Confirm" name="btn">
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</body>

</html>








