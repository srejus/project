<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

	<title>Register</title>

	<!-- Google font -->
	<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet">

	<!-- Bootstrap -->
	<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css" />

	<!-- Custom stlylesheet -->
	<link type="text/css" rel="stylesheet" href="css/style.css" />


</head>

<body>
	<div id="booking-1" class="section">
		<?php
			include('nav.html');
		?>
		<div class="section-center">
			<div class="container">
				<div class="row">
					<div class="col-md-7 col-md-push-5">
						<div class="booking-cta">
							<h1>Make your reservation</h1>
							<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Animi facere, soluta magnam consectetur molestias itaque
								ad sint fugit architecto incidunt iste culpa perspiciatis possimus voluptates aliquid consequuntur cumque quasi.
								Perspiciatis.
							</p>
						</div>
					</div>
					<div class="col-md-4 col-md-pull-7">
						<div class="booking-form">
							<form  action="register.php" method="POST">
                                <h1>Register your Account</h1><br>
								<div class="form-group">
									<span class="form-label">Username</span>
									<input name="username" class="form-control" type="text" placeholder="Enter username">
								</div>

								<div class="form-group">
									<span class="form-label">Password</span>
									<input name="password1" class="form-control" type="password" placeholder="Enter Password">
								</div>

                                <div class="form-group">
									<span class="form-label">Confirm Password</span>
									<input name="password2" class="form-control" type="password" placeholder="Enter Password again">
								</div>

								

								
								<div class="form-btn">
									<button type="submit" name="register" class="submit-btn">Register</button>
								</div><br>
								<a href="login.php">Already have an account</a>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</body>

</html>

<?php
	include('connect.php');

	//Fetch data from HTML Form
	if(isset($_POST['register'])){
		$username = $_POST['username'];
		$pass1 = $_POST['password1'];
		$pass2 = $_POST['password2'];

		//Check if the user exist
		$sql_user = "SELECT * FROM user WHERE username='$username'";
	
		$res_user = mysqli_query($conn,$sql_user);
		if($res_user){
			//try to get data fromDB
			$row_num = mysqli_num_rows($res_user);
			if($row_num == 0){
				//Password checking
				if($pass1 == $pass2){
					$sql = "INSERT INTO user(username,password) VALUES('$username','$pass1')";

					$res = mysqli_query($conn,$sql);

					if($res){
						echo "<script>alert('Account Created!');</script>";
						header('Location:login.php');
					}
					else{
						echo "<script>alert('Error while creating account try again later!');</script>";
					}
				}
				else{
					echo "<script>alert('Password not Matching!');</script>";
				}
			}
			else{
				echo "<script>alert('Username already Exists!');</script>";
			}
		}

		
	}

?>