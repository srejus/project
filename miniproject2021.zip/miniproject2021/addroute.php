<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

	<title>Admin | Addroute</title>

	<!-- Google font -->
	<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet">

	<!-- Bootstrap -->
	<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css" />

	<!-- Custom stlylesheet -->
	<link type="text/css" rel="stylesheet" href="css/style.css" />


</head>

<body>
	<div id="booking-1" class="section">
    <a class="a" style="margin-left:50px;" href="logout.php">Logout</a>
		<div class="section-center">
			<div class="container">
				<div class="row">
					<div class="col-md-7 col-md-push-5">
						
					</div>
					<div class="col-md-4 col-md-pull-7">
						<div class="booking-form">
							<form action="addroute.php" method="POST">
                            <h3>Add Route</h3><br>
								<div class="form-group">
									<span class="form-label">Origin</span>
                                    <select class="form-control" name="origin">
										<option value="">Select your Origin</option>
										<option value="Kochi">Kochi</option>
										<option value="Kozhikode">Kozhikode</option>
										<option value="Kollam">Kollam</option>
										<option value="Alappuzha">Alappuzha</option>
										<option value="Trivandrum">Trivandrum</option>
									</select>
								</div>

								<div class="form-group">
									<span class="form-label">Destination</span>
									<select class="form-control" name="destination">
										<option value="">Select your Destination</option>
										<option value="Kochi">Kochi</option>
										<option value="Kozhikode">Kozhikode</option>
										<option value="Kollam">Kollam</option>
										<option value="Alappuzha">Alappuzha</option>
										<option value="Trivandrum">Trivandrum</option>
									</select>
									
								</div>

                                <div class="form-group">
									<span class="form-label">Date</span>
									<input name="date" class="form-control" type="text" placeholder="Enter Date">
								</div>

                                <div class="form-group">
									<span class="form-label">Total seats</span>
									<input name="seats" class="form-control" type="text" placeholder="Enter Seats">
								</div>

                                <div class="form-group">
									<span class="form-label">Type of Bus</span><br>
									<input  name="ac" type="radio" value="ac">A/c &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
									<input name="ac" type="radio" value="nonac">Non A/C
								</div>

								
								<div class="form-btn">
									<button type="submit" name="save" class="submit-btn">Save Route</button>
								</div><br>
								
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</body>

</html>


<?php

include('connect.php');
//Fetch data from Form

if(isset($_POST['save'])){
    $origin = $_POST['origin'];
	$destination = $_POST['destination'];
	$seatno = $_POST['seats'];
	$date = $_POST['date'];
	$ac = $_POST['ac'];

    $sql = "INSERT INTO routes(origin,destination,date,seats,type) VALUES('$origin','$destination','$date','$seatno','$ac')";

    $res = mysqli_query($conn,$sql);

    if($res){
        echo "<script>alert('Route added!');</script>";
        header('Location:routes.php');
    }
}

?>